import unittest

class MonsterTests(unittest.TestCase):
   def test_monster(self):
      # Add code here.


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

