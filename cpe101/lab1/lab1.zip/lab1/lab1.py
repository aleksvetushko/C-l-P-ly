#
# This is a header block example for lab 1.
#
# You will need to supply the following information.
#
# Name:
# Instructor: 
# Section:
#

print ("Hello, World.")
