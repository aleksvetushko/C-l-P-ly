import unittest
import funcs

class TestCases(unittest.TestCase):
   def test_square(self):
      # Add code here.
      pass


   def test_f(self):
      # Add code here.
      pass


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

