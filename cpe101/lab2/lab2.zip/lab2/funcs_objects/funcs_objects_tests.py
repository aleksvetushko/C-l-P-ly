import unittest
import funcs

class TestCases(unittest.TestCase):
   def test_cases(self):
      # Add code here.


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

